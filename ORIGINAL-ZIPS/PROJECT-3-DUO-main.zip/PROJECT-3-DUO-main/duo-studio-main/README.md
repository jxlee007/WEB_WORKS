Note: Use this source code when you get some issues or doubts.
