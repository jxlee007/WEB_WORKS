# PROJECT 2

full clone a famous photography youtuber website with parallax-scroll, 
sutle loading pages effects using css and cart system made from javascript with mobile optimization version 
